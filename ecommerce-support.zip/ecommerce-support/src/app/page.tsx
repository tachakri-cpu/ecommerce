import Link from 'next/link'

export default function Home() {
  return (
    <main className="mx-auto max-w-5xl p-6 space-y-6">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Ecommerce Support</h1>
        <nav className="space-x-4 text-sm">
          <Link href="/dashboard">Dashboard</Link>
          <Link href="/docs/deploy">Deploy</Link>
        </nav>
      </header>

      <section className="grid gap-4 md:grid-cols-3">
        <div className="rounded-lg border bg-white p-4">
          <h2 className="font-medium">CSAT</h2>
          <p className="text-sm text-gray-600">Capture post-resolution ratings and comments.</p>
        </div>
        <div className="rounded-lg border bg-white p-4">
          <h2 className="font-medium">Behavior</h2>
          <p className="text-sm text-gray-600">Track events and analyze funnels/retention.</p>
        </div>
        <div className="rounded-lg border bg-white p-4">
          <h2 className="font-medium">Predictions</h2>
          <p className="text-sm text-gray-600">Propensity scoring and segments.</p>
        </div>
      </section>

      <section className="rounded-lg border bg-white p-4">
        <h3 className="font-medium mb-2">Next steps</h3>
        <ol className="list-decimal list-inside text-sm text-gray-700 space-y-1">
          <li>Set up a Postgres DB (Supabase) and add DATABASE_URL on Vercel.</li>
          <li>Run Prisma migrations in a Vercel Build or via CLI.</li>
          <li>Use API routes to ingest CSAT and behavior events.</li>
        </ol>
      </section>
    </main>
  )
}
