export default function DeployDocs() {
  return (
    <main className="mx-auto max-w-3xl p-6 space-y-4">
      <h1 className="text-2xl font-semibold">Deploy to Vercel + Supabase</h1>
      <ol className="list-decimal list-inside space-y-2 text-sm text-gray-700">
        <li>Create a new GitHub repository and push this folder.</li>
        <li>Create a Supabase project (free tier) and copy the Postgres connection string to <code>DATABASE_URL</code>.</li>
        <li>On Vercel, import your GitHub repo and set the environment variable <code>DATABASE_URL</code> under Project Settings &gt; Environment Variables.</li>
        <li>Trigger a deploy. The build runs <code>prisma db push</code> to create tables automatically.</li>
        <li>Use the API routes to send data:
          <ul className="list-disc list-inside ml-6">
            <li>POST /api/csat/response</li>
            <li>GET /api/csat/summary</li>
            <li>POST /api/events/ingest</li>
            <li>GET /api/events/summary</li>
            <li>GET /api/behavior/funnels</li>
            <li>GET /api/behavior/retention</li>
            <li>GET /api/predictions/customer/:id</li>
          </ul>
        </li>
      </ol>
      <p className="text-sm text-gray-600">Optional: connect Shopify webhooks to <code>/api/events/ingest</code> for purchase events.</p>
    </main>
  )
}
