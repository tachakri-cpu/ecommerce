import { prisma } from '@/lib/prisma'

export default async function Summary() {
  const [csatCount, eventsCount, predsCount] = await Promise.all([
    prisma.cSATResponse.count(),
    prisma.event.count(),
    prisma.prediction.count(),
  ])
  return (
    <section className="grid gap-4 md:grid-cols-3">
      <div className="rounded-lg border bg-white p-4">
        <div className="text-sm text-gray-500">CSAT Responses</div>
        <div className="text-2xl font-semibold">{csatCount}</div>
      </div>
      <div className="rounded-lg border bg-white p-4">
        <div className="text-sm text-gray-500">Events</div>
        <div className="text-2xl font-semibold">{eventsCount}</div>
      </div>
      <div className="rounded-lg border bg-white p-4">
        <div className="text-sm text-gray-500">Predictions</div>
        <div className="text-2xl font-semibold">{predsCount}</div>
      </div>
    </section>
  )
}
