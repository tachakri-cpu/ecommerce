import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const from = searchParams.get('from')
    const to = searchParams.get('to')

    const where: any = {}
    if (from || to) {
      where.submittedAt = {}
      if (from) where.submittedAt.gte = new Date(from)
      if (to) where.submittedAt.lte = new Date(to)
    }

    const [count, avg, responses] = await Promise.all([
      prisma.cSATResponse.count({ where }),
      prisma.cSATResponse.aggregate({ where, _avg: { score: true } }),
      prisma.cSATResponse.groupBy({ by: ['score'], _count: { _all: true }, where })
    ])

    return NextResponse.json({
      count,
      average: avg._avg.score ?? null,
      distribution: responses.map(r => ({ score: r.score, count: r._count._all }))
    })
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Server error' }, { status: 500 })
  }
}
