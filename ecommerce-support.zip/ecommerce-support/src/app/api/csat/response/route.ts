import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { ticketId, customerId, score, comment, channel } = body as {
      ticketId?: string
      customerId?: string
      score?: number
      comment?: string
      channel?: string
    }

    if (!ticketId || !customerId || typeof score !== 'number') {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const csat = await prisma.cSATResponse.create({
      data: {
        ticketId,
        customerId,
        score,
        comment,
        channel: channel ?? 'widget',
      },
    })

    return NextResponse.json({ ok: true, id: csat.id })
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Server error' }, { status: 500 })
  }
}
