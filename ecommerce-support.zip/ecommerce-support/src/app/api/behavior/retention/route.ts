import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// Basic weekly purchase retention over 4 weeks based on first purchase week cohorts
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const weeks = parseInt(searchParams.get('weeks') || '4', 10)

    // get all purchase events in last (weeks+1)*7*2 days to be safe
    const since = new Date(Date.now() - (weeks + 6) * 7 * 24 * 3600 * 1000)
    const purchases = await prisma.event.findMany({
      where: { type: 'purchase', occurredAt: { gte: since } },
      select: { customerId: true, occurredAt: true },
      orderBy: { occurredAt: 'asc' }
    })

    const cohortStart = new Map<string, Date>() // customerId -> first purchase week start
    const cohorts: Record<string, Set<string>> = {}

    function weekStart(d: Date) {
      const dt = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()))
      const day = dt.getUTCDay()
      const diff = (day + 6) % 7 // week starts Monday
      dt.setUTCDate(dt.getUTCDate() - diff)
      return dt
    }

    for (const p of purchases) {
      const cid = p.customerId
      if (!cid) continue
      const w0 = weekStart(p.occurredAt)
      if (!cohortStart.has(cid)) cohortStart.set(cid, w0)
      const key = weekStart(cohortStart.get(cid)!).toISOString()
      if (!cohorts[key]) cohorts[key] = new Set()
      cohorts[key].add(cid)
    }

    // build retention matrix
    const matrix: { cohort: string; size: number; retention: number[] }[] = []
    for (const [cohort, customers] of Object.entries(cohorts)) {
      const size = customers.size
      const base = new Date(cohort)
      const retention: number[] = []
      for (let w = 0; w <= weeks; w++) {
        const start = new Date(base)
        start.setUTCDate(start.getUTCDate() + w * 7)
        const end = new Date(start)
        end.setUTCDate(start.getUTCDate() + 7)
        const active = new Set<string>()
        for (const p of purchases) {
          if (!p.customerId) continue
          if (!customers.has(p.customerId)) continue
          if (p.occurredAt >= start && p.occurredAt < end) active.add(p.customerId)
        }
        retention.push(size === 0 ? 0 : Math.round((active.size / size) * 100))
      }
      matrix.push({ cohort, size, retention })
    }

    return NextResponse.json({ weeks, cohorts: matrix })
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Server error' }, { status: 500 })
  }
}
