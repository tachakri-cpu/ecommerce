import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// Very simple funnel: counts unique customers/sessions that did each step within window
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const stepsParam = searchParams.get('steps') || 'product_view,add_to_cart,checkout_start,purchase'
    const from = searchParams.get('from')
    const to = searchParams.get('to')
    const scope = searchParams.get('scope') || 'customer' // 'customer' | 'session'

    const steps = stepsParam.split(',').map(s => s.trim()).filter(Boolean)
    const where: any = {}
    if (from || to) {
      where.occurredAt = {}
      if (from) where.occurredAt.gte = new Date(from)
      if (to) where.occurredAt.lte = new Date(to)
    }

    const results = [] as { step: string, count: number }[]
    for (const step of steps) {
      const rows = await prisma.event.findMany({
        where: { ...where, type: step },
        select: scope === 'customer' ? { customerId: true } : { sessionId: true }
      })
      const set = new Set(rows.map(r => (scope === 'customer' ? (r as any).customerId : (r as any).sessionId)).filter(Boolean))
      results.push({ step, count: set.size })
    }

    return NextResponse.json({ steps: results })
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Server error' }, { status: 500 })
  }
}
