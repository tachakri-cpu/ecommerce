import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

interface EventInput {
  customerId?: string
  sessionId?: string
  type: string
  properties?: Record<string, any>
  source?: string
  userAgent?: string
  occurredAt?: string
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const events: EventInput[] = Array.isArray(body) ? body : [body]

    const data = await Promise.all(
      events.map(async (e) => {
        const sessionId = e.sessionId ?? crypto.randomUUID()
        // upsert session
        await prisma.session.upsert({
          where: { id: sessionId },
          update: { lastSeenAt: new Date() },
          create: { id: sessionId },
        })
        // write event
        const created = await prisma.event.create({
          data: {
            customerId: e.customerId,
            sessionId,
            type: e.type,
            properties: (e.properties ?? {}) as any,
            source: e.source ?? 'web',
            userAgent: e.userAgent,
            occurredAt: e.occurredAt ? new Date(e.occurredAt) : new Date(),
          },
        })
        // link identity if provided
        if (e.customerId) {
          await prisma.identityLink.create({
            data: { sessionId, customerId: e.customerId },
          }).catch(() => {})
        }
        return { id: created.id, sessionId }
      })
    )

    return NextResponse.json({ ok: true, items: data })
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Server error' }, { status: 500 })
  }
}
