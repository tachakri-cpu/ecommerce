import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const from = searchParams.get('from')
    const to = searchParams.get('to')
    const type = searchParams.get('type')

    const where: any = {}
    if (from || to) {
      where.occurredAt = {}
      if (from) where.occurredAt.gte = new Date(from)
      if (to) where.occurredAt.lte = new Date(to)
    }
    if (type) where.type = type

    const [count, byType] = await Promise.all([
      prisma.event.count({ where }),
      prisma.event.groupBy({ by: ['type'], _count: { _all: true }, where })
    ])

    return NextResponse.json({ count, byType })
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Server error' }, { status: 500 })
  }
}
