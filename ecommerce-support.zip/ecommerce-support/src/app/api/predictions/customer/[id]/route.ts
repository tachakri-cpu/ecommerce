import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const { id } = params
    const pred = await prisma.prediction.findFirst({
      where: { customerId: id },
      orderBy: { scoredAt: 'desc' }
    })
    return NextResponse.json({ prediction: pred ?? null })
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Server error' }, { status: 500 })
  }
}
