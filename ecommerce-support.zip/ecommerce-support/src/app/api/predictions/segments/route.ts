import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const min = parseFloat(searchParams.get('min') || '0.7')
    const limit = parseInt(searchParams.get('limit') || '100', 10)

    const preds = await prisma.prediction.findMany({
      where: { propensity: { gte: min } },
      orderBy: { propensity: 'desc' },
      take: limit
    })

    return NextResponse.json({ items: preds })
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'Server error' }, { status: 500 })
  }
}
